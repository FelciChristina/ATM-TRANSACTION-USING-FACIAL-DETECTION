from django.shortcuts import redirect, render
from .models import UserModel,Account,Transaction
from .facedetect import detect
from .facerecognition import recognize
from django.db.models import Q
from django.http import HttpResponse
import random
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# Create your views here.

def sendmail(otp,email):
    # Email account credentials
    email_address = 'lakshatvr@gmail.com'
    password = 'yofteltqzjqaubxd'

    # Email details
    recipient = email
    subject = 'OTP'
    body = otp

    # Create message
    message = MIMEMultipart()
    message['From'] = email_address
    message['To'] = recipient
    message['Subject'] = subject
    message.attach(MIMEText(body, 'plain'))

    # Connect to SMTP server
    smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
    smtp_server.starttls()
    smtp_server.login(email_address, password)

    # Send email
    smtp_server.send_message(message)

    # Quit SMTP server
    smtp_server.quit()

    print("Email sent successfully!")

    
def home(request):
    return render(request,"home.html")

def signup(request,method=['GET','POST']):
    if request.method=='POST':
        username=request.POST.get("username")
        passw1=request.POST.get("passw1")
        passw2=request.POST.get("passw2")
        email=request.POST.get("email")
        acc=request.POST.get("acc")
        address=request.POST.get("address")
        q=UserModel.objects.filter(username=username)
       
        msg="User already exists"
        if(q):
            return render(request,"signup.html",{"msg":msg})
        else:
            detect(username)
            UserModel.objects.create(username=username,password=passw1,email=email,acc_number=acc,address=address)
            q=UserModel.objects.get(username=username)
            Account.objects.create(user=q,balance=1000)
            return render(request,"login.html")

    return render(request,"signup.html")

def login(request,method=['GET','POST']):
    if request.method=='POST':
        username=request.POST.get("username")
        password=request.POST.get("password")
        name=recognize()
        q=UserModel.objects.filter(Q(username=username,password=password)&Q(username=name))
        msg="User not found"
        if(q):
            otp = random.randint(1000, 9999)
            print(otp)
            email=q[0].email
            
            request.session["username"]=q[0].username
            request.session["otp"]=str(otp)
            sendmail(str(otp),email)
            return render(request,"otp.html")
        else:
            return render(request,"login.html",{"msg":msg})
    return render(request,"login.html")

def otp(request,method=['GET','POST']):
    if request.method=="POST":
        one=request.POST.get("1") 
        two=request.POST.get("2") 
        three=request.POST.get("3") 
        four=request.POST.get("4") 
        otp_entered=int(one)*1000+int(two)*100+int(three)*10+int(four)
        print(otp_entered)
        otp=request.session['otp']
        print(request.session['otp'])
        if(otp==str(otp_entered)):
            return render(request,'main.html')
    return render(request,'otp.html')
def transaction(request,method=['GET','POST']):
    msg=''
    if request.method=="POST":
        sender=request.session["username"]
        acc_number=request.POST.get("acc_num")
        amount=request.POST.get("amt") 
        receiver=UserModel.objects.all().filter(acc_number=acc_number)
        re_name=receiver[0].username
        if(receiver):
            Transaction.objects.create(sender_name=sender,receiver=receiver[0],amount=amount)
            se=UserModel.objects.get(username=sender)
            re=UserModel.objects.get(username=re_name)
            s=Account.objects.get(user=se)
            r=Account.objects.get(user=re)
            if(s.balance>int(amount)):
                
                r.balance=r.balance+int(amount)
                r.save()
                s.balance=s.balance-int(amount)
                s.save()
                return render(request,"sucessful.html")
            else:
                return HttpResponse("No sufficient balance")
        else:
            msg="Account number does not exists!!"
            return render(request,"transaction.html",{"msg":msg})
    return render(request,"transaction.html")
def statement(request):
    user=request.session["username"]
    q=Transaction.objects.filter(sender_name=user)
    return render(request,"statement.html",{"q":q})

def logout(request):
    del request.session["username"]
    return render(request,"home.html")

def myaccount(request):
    user=request.session["username"]
    se=UserModel.objects.get(username=user)
    s=Account.objects.get(user=se)
    return render(request,"myaccount.html",{"s":s})

def main(request):
    if 'username' not in request.session:
        return redirect('login')  # Redirect to login if the session is expired or not found
    return render(request, 'main.html')


