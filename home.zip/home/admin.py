from django.contrib import admin
from .models import UserModel,Account,Transaction
# Register your models here.

admin.site.register(UserModel)
admin.site.register(Account)
admin.site.register(Transaction)